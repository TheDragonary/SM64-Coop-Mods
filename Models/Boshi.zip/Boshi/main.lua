-- name: Boshi
-- description: Play as Boshi\n\nMod created by Dragonary

E_MODEL_BOSHI = smlua_model_util_get_id("boshi_geo")

function boshi(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "on" then
		gPlayerSyncTable[0].modelId = E_MODEL_BOSHI
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("boshi", "[on|off] - Play as Boshi", boshi)