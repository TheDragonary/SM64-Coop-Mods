-- name: Noob Model
-- incompatible:
-- description: [on/oof]

local gCharacterModels = {
    [CT_MARIO] = smlua_model_util_get_id("noob_geo"),
    [CT_LUIGI] = smlua_model_util_get_id("noob_geo"),
    [CT_TOAD] = smlua_model_util_get_id("noob_geo"),
    [CT_WARIO] = smlua_model_util_get_id("noob_geo"),
	[CT_WALUIGI] = smlua_model_util_get_id("noob_geo"),
}

--- @param m MarioState
local function mario_update(m)
    local model = gCharacterModels[m.character.type]
    if gPlayerSyncTable[m.playerIndex].noobModel and model ~= nil then
        obj_set_model_extended(m.marioObj, model)
    end
end

function on_noobModel_command(msg)
    if msg == "on" then
        gPlayerSyncTable[0].noobModel = true
        djui_chat_message_create("can i has chezburger plz")
    elseif msg == "off" then
        gPlayerSyncTable[0].noobModel = false
        djui_chat_message_create("oof")
    end
    return true
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("noob", "[on/oof] turns you into a noob", on_noobModel_command)

for i = 0, (MAX_PLAYERS) - 1 do
    gPlayerSyncTable[i].noobModel = false
end