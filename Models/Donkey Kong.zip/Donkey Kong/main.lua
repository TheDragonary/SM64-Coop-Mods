-- name: Donkey Kong
-- description: Play as Donkey Kong\n\nMod created by Dragonary

E_MODEL_DK = smlua_model_util_get_id("dk_geo")

function dk(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "on" then
		gPlayerSyncTable[0].modelId = E_MODEL_DK
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("donkeykong", "[on|off] - Play as Donkey Kong", dk)