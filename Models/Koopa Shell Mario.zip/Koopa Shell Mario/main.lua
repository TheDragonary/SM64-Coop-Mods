-- name: Koopa Shell Mario
-- description: Play as Koopa Shell Mario\n\nMod created by Dragonary

E_MODEL_KSM = smlua_model_util_get_id("ksm_geo")

function ksm(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "on" then
		gPlayerSyncTable[0].modelId = E_MODEL_KSM
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("koopashellmario", "[on|off] - Play as Koopa Shell Mario", ksm)