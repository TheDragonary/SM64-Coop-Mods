-- name: Mr. L & M
-- description: Play as Mr. L or Mr. M\n\nMod created by Dragonary

E_MODEL_MRL = smlua_model_util_get_id("mrl_geo")
E_MODEL_MRM = smlua_model_util_get_id("mrm_geo")

function mr(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "l" then
		gPlayerSyncTable[0].modelId = E_MODEL_MRL
		return true
	elseif msg == "m" then
		gPlayerSyncTable[0].modelId = E_MODEL_MRM
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("mr", "[l|m|off] - Play as Mr. L or Mr. M", mr)