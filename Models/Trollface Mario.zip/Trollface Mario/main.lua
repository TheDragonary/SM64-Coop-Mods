-- name: Trollface Mario
-- description: Play as Trollface Mario\n\nMod created by Dragonary

E_MODEL_TROLLFACE = smlua_model_util_get_id("trollface_geo")

function trollface(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "on" then
		gPlayerSyncTable[0].modelId = E_MODEL_TROLLFACE
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("trollface", "[on|off] - Play as Trollface Mario", trollface)