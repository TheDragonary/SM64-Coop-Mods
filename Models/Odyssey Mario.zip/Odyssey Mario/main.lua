-- name: \\#2FA0EF\\Odyssey \\#1251D2\\Mario 
-- description: Super Mario Odyssey model with voice\n\n\\#2FEF6A\\CHAT COMMAND: /odyssey on or odyssey off
E_MODEL_SMO_PLAYER = smlua_model_util_get_id("smo_player_geo")

ACT_FLUTTER = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)
ACT_FLUTTER_FREEFALL = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION)

local smo_model = false

ANGLE_QUEUE_SIZE = 9

gEventTable = {}

gStateExtras = {}
for i = 0, (MAX_PLAYERS - 1) do
    gStateExtras[i] = {}
    local m = gMarioStates[i]
    local e = gStateExtras[i]
    e.canflutter = true
    e.angleDeltaQueue = {}
    for j = 0, (ANGLE_QUEUE_SIZE - 1) do e.angleDeltaQueue[j] = 0 end
    e.animFrame = 0
end

function act_flutter(m)
    local e = gStateExtras[m.playerIndex]

    common_air_action_step(m, ACT_JUMP_LAND, MARIO_ANIM_RUNNING_UNUSED, AIR_STEP_NONE)

    play_sound(SOUND_ACTION_TWIRL, m.marioObj.header.gfx.cameraToObject)

    if m.actionTimer == 0 then
        m.actionState = m.actionArg
        play_sound(SOUND_GENERAL_SMO_TALK, m.marioObj.header.gfx.cameraToObject)
    end

    m.vel.y = m.actionTimer / 2
    if m.prevAction ~= ACT_TRIPLE_JUMP then  
        if m.actionTimer > 30 or (m.controller.buttonDown & A_BUTTON) == 0 then
            set_mario_action(m, ACT_FREEFALL, 0)
        end
    else
        if m.actionTimer > 30 or (m.controller.buttonDown & A_BUTTON) == 0 then
            set_mario_action(m, ACT_FLUTTER_FREEFALL, 0)
        end
    end

    set_mario_animation(m, MARIO_ANIM_RUNNING_UNUSED)
    set_anim_to_frame(m, e.animFrame)
    e.animFrame = e.animFrame + 10
    if e.animFrame >= m.marioObj.header.gfx.animInfo.curAnim.loopEnd then
        e.animFrame = e.animFrame - m.marioObj.header.gfx.animInfo.curAnim.loopEnd
    end

    m.actionTimer = m.actionTimer + 1
    return 0
end

function act_flutter_freefall(m)
    local e = gStateExtras[m.playerIndex]

    common_air_action_step(m, ACT_TRIPLE_JUMP_LAND, MARIO_ANIM_FORWARD_SPINNING, AIR_STEP_NONE)
end

function smo_command(msg)
    if msg == 'on' then
        gPlayerSyncTable[0].heMario = true
        smo_model = true
        djui_chat_message_create('\\#0EDAES\\ODYSSEY \\#0EDAE8\\Model on!')
        return true
    elseif msg == "off" then
        gPlayerSyncTable[0].heMario = false
        smo_model = false
        djui_chat_message_create('\\#0EDAE8\\ODYSSEY \\#0EDAE8\\Model off')
        return true
    end
    return false
end

function mario_update_local(m)
    if smo_model == true then
        gPlayerSyncTable[0].modelId = E_MODEL_SMO_PLAYER
    end
    if smo_model == false then
		gPlayerSyncTable[0].modelId = nil
	end
end

function mario_update(m)
    local e = gStateExtras[m.playerIndex]
    local s = gPlayerSyncTable[m.playerIndex]
    local np = gNetworkPlayers[m.playerIndex]

    if smo == true and gMarioStates[0].character.type == 0 then

        if e.canflutter == true then
            if (m.controller.buttonPressed & A_BUTTON) ~= 0 and m.actionTimer > 0 then
                if m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_LONG_JUMP or m.action == ACT_BACKFLIP or m.action == ACT_SIDE_FLIP or m.action == ACT_FREEFALL then
                    set_mario_action(m, ACT_FLUTTER, 0)
                    e.canflutter = false
                end
            end
        end
        if m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_LONG_JUMP or  m.action == ACT_SIDE_FLIP or m.action == ACT_FREEFALL or m.action == ACT_BACKFLIP then
            m.actionTimer = m.actionTimer + 1
        end
        if m.action == ACT_JUMP_LAND or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP_LAND or m.action == ACT_IDLE or m.action == ACT_WALKING then
            e.canflutter = true
        end

        --No Walljump from flutter
        if e.canflutter == false and m.action == ACT_AIR_HIT_WALL then
            set_mario_action(m, ACT_BUTT_SLIDE_AIR, 0)
        end
    end

    if s.heMario then
        np.overrideModelIndex = 0
    else
        np.overrideModelIndex = np.modelIndex
    end

    if m.playerIndex == 0 then
        mario_update_local(m)
    end

    if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
        obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
    end

    if gPlayerSyncTable[0].modelId ~= E_MODEL_SMO_PLAYER then return end
end

function mario_on_set_action(m)
    if smo == true and gMarioStates[0].character.type == 0 then

        if m.action == ACT_DIVE and m.prevAction ~= ACT_TRIPLE_JUMP and (m.marioObj.collidedObjInteractTypes & INTERACT_GRABBABLE) == 0 then
            set_mario_action(m, ACT_JUMP_KICK, 0)
            if m.forwardVel > 0 then
                m.forwardVel = m.forwardVel -15
            end
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)

hook_mario_action(ACT_FLUTTER,     { every_frame = act_flutter })
hook_mario_action(ACT_FLUTTER_FREEFALL,     { every_frame = act_flutter_freefall })

hook_chat_command('odyssey', "[\\#ffffff\\on\\#ffffff\\|\\#ffffff\\off\\#ffffff\\] turn \\#ffffff\\the smo model\\#ffffff\\ \\#ffffff\\on \\#ffffff\\or \\#ffffff\\off", smo_command)

for i=0,(MAX_PLAYERS-1) do
    local s = gPlayerSyncTable[i]
    s.heMario = false
end

--Define what triggers the custom voice
local function use_custom_voice(m)
    return smo_model == true --Put your condition here!
end

--How many snores the sleep-talk has, or rather, how long the sleep-talk lasts
--If you omit the sleep-talk you can ignore this
local SLEEP_TALK_SNORES = 8

--Define what actions play what voice clips
--If an action has more than one voice clip, put those clips inside a table
--CHAR_SOUND_SNORING3 requires two or three voice clips to work properly...
--but you can omit it if your character does not sleep-talk
local CUSTOM_VOICETABLE = {
    [CHAR_SOUND_ATTACKED] = 'sound_mario_attacked.ogg',
    [CHAR_SOUND_COUGHING1] = 'sound_mario_coughing1.ogg',
    [CHAR_SOUND_COUGHING2] = 'sound_mario_coughing2.ogg',
    [CHAR_SOUND_COUGHING3] = 'sound_mario_coughing3.ogg',
    [CHAR_SOUND_DOH] = 'sound_mario_doh.ogg',
    [CHAR_SOUND_DROWNING] = 'sound_mario_drowning.ogg',
    [CHAR_SOUND_DYING] = 'sound_mario_dying.ogg',
    [CHAR_SOUND_EEUH] = 'sound_mario_eeuh.ogg',
    [CHAR_SOUND_GAME_OVER] = 'sound_mario_game_over.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'sound_mario_wah.ogg',
    [CHAR_SOUND_HAHA] = 'sound_mario_haha.ogg',
    [CHAR_SOUND_HAHA_2] = 'sound_mario_haha_2.ogg',
    [CHAR_SOUND_HELLO] = 'sound_mario_hello.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'sound_mario_here_we_go.ogg',
    [CHAR_SOUND_HOOHOO] = 'sound_mario_hoohoo.ogg',
    [CHAR_SOUND_HRMM] = 'sound_mario_hrmm.ogg',
    [CHAR_SOUND_IMA_TIRED] = 'sound_mario_ima_tired.ogg',
    [CHAR_SOUND_LETS_A_GO] = 'sound_mario_lets_a_go.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'sound_mario_mama_mia.ogg',
    [CHAR_SOUND_OKEY_DOKEY] = 'sound_mario_okey_dokey.ogg',
    [CHAR_SOUND_ON_FIRE] = 'sound_mario_on_fire.ogg',
    [CHAR_SOUND_OOOF] = 'sound_mario_ooof.ogg',
    [CHAR_SOUND_OOOF2] = 'sound_mario_ooof2.ogg',
    [CHAR_SOUND_PANTING] = {'sound_mario_panting1.ogg', 'sound_mario_panting2.ogg', 'sound_mario_panting3.ogg'},
    [CHAR_SOUND_PANTING_COLD] = 'sound_mario_panting_cold.ogg',
    [CHAR_SOUND_PRESS_START_TO_PLAY] = 'sound_mario_press_start_to_play.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'sound_mario_punch_hoo.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'sound_mario_punch_wah.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'sound_mario_punch_yah.ogg',
    [CHAR_SOUND_SNORING1] = 'sound_mario_snoring1.ogg',
    [CHAR_SOUND_SNORING2] = 'sound_mario_snoring2.ogg',
    [CHAR_SOUND_SNORING3] = {'sound_mario_snoring3.ogg', 'sound_mario_snoring4.ogg', 'sound_mario_sleep_talk.ogg'},
    [CHAR_SOUND_SO_LONGA_BOWSER] = 'sound_mario_so_longa_bowser.ogg',
    [CHAR_SOUND_TWIRL_BOUNCE] = 'sound_mario_twirl_bounce.ogg',
    [CHAR_SOUND_UH] = 'sound_mario_uh.ogg',
    [CHAR_SOUND_UH2] = 'sound_mario_uh2.ogg',
    [CHAR_SOUND_UH2_2] = 'sound_mario_uh2_2.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'sound_mario_waaaooow.ogg',
    [CHAR_SOUND_WAH2] = 'sound_mario_wah2.ogg',
    [CHAR_SOUND_WHOA] = 'sound_mario_whoa.ogg',
    [CHAR_SOUND_YAHOO] = 'sound_mario_yahoo.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'sound_mario_yahoo_1.ogg', 'sound_mario_yahoo_2.ogg', 'sound_mario_waha.ogg', 'sound_mario_yippee.ogg'},
    [CHAR_SOUND_YAH_WAH_HOO] = {'sound_mario_jump_yah.ogg', 'sound_mario_jump_wah.ogg', 'sound_mario_jump_hoo.ogg'},
    [CHAR_SOUND_YAWNING] = 'sound_mario_yawning.ogg',
}

--Define the table of samples that will be used for each player
--Global so if multiple mods use this they won't create unneeded samples
--DON'T MODIFY THIS SINCE IT'S GLOBAL FOR USE BY OTHER MODS!
gCustomVoiceSamples = {}
gCustomVoiceStream = nil

--Get the player's sample, stop whatever sound
--it's playing if it doesn't match the provided sound
--DON'T MODIFY THIS SINCE IT'S GLOBAL FOR USE BY OTHER MODS!
--- @param m MarioState
function stop_custom_character_sound(m, sound)
    local voice_sample = gCustomVoiceSamples[m.playerIndex]
    if voice_sample == nil or not voice_sample.loaded then
        return
    end

    audio_sample_stop(voice_sample)
    if voice_sample.file.relativePath:match('^.+/(.+)$') == sound then
        return voice_sample
    end
    audio_sample_destroy(voice_sample)
end

--Play a custom character's sound
--DON'T MODIFY THIS SINCE IT'S GLOBAL FOR USE BY OTHER MODS!
--- @param m MarioState
function play_custom_character_sound(m, voice)
    --Get sound, if it's a table, get a random entry from it
    local sound
    if type(voice) == "table" then
        sound = voice[math.random(#voice)]
    else
        sound = voice
    end
    if sound == nil then return 0 end

    --Get current sample and stop it
    local voice_sample = stop_custom_character_sound(m, sound)

    --If the new sound isn't a string, let's assume it's
    --a number to return to the character sound hook
    if type(sound) ~= "string" then
        return sound
    end

    --Load a new sample and play it! Don't make a new one if we don't need to
    if (m.area == nil or m.area.camera == nil) and m.playerIndex == 0 then
        if gCustomVoiceStream ~= nil then
            audio_stream_stop(gCustomVoiceStream)
            audio_stream_destroy(gCustomVoiceStream)
        end
        gCustomVoiceStream = audio_stream_load(sound)
        audio_stream_play(gCustomVoiceStream, true, 1)
    else
        if voice_sample == nil then
            voice_sample = audio_sample_load(sound)
        end
        audio_sample_play(voice_sample, m.pos, 1)

        gCustomVoiceSamples[m.playerIndex] = voice_sample
    end
    return 0
end

--Main character sound hook
--This hook is freely modifiable in case you want to make any specific exceptions
--- @param m MarioState
local function custom_character_sound(m, characterSound)
    if not use_custom_voice(m) then return end
    if characterSound == CHAR_SOUND_SNORING3 then return 0 end
    if characterSound == CHAR_SOUND_HAHA and m.hurtCounter > 0 then return 0 end

    local voice = CUSTOM_VOICETABLE[characterSound]
    if voice ~= nil then
        return play_custom_character_sound(m, voice)
    end
    return 0
end
hook_event(HOOK_CHARACTER_SOUND, custom_character_sound)

--Snoring logic for CHAR_SOUND_SNORING3 since we have to loop it manually
--This code won't activate on the Japanese version, due to MARIO_MARIO_SOUND_PLAYED not being set
local SNORE3_TABLE = CUSTOM_VOICETABLE[CHAR_SOUND_SNORING3]
local STARTING_SNORE = 46
local SLEEP_TALK_START = STARTING_SNORE + 49
local SLEEP_TALK_END = SLEEP_TALK_START + SLEEP_TALK_SNORES

--Main hook for snoring
--- @param m MarioState
local function custom_character_snore(m)
    if not use_custom_voice(m) then return end

    --Stop the snoring!
    if m.action ~= ACT_SLEEPING then
        if m.isSnoring > 0 then
            stop_custom_character_sound(m)
        end
        return

    --You're not in deep snoring
    elseif not (m.actionState == 2 and (m.flags & MARIO_MARIO_SOUND_PLAYED) ~= 0) then
        return
    end

    local animFrame = m.marioObj.header.gfx.animInfo.animFrame

    --Behavior for CHAR_SOUND_SNORING3
    if SNORE3_TABLE ~= nil and #SNORE3_TABLE >= 2 then
        --Exhale sound
        if animFrame == 2 and m.actionTimer < SLEEP_TALK_START then
            play_custom_character_sound(m, SNORE3_TABLE[2])

        --Inhale sound
        elseif animFrame == 25 then
            
            --Count up snores
            if #SNORE3_TABLE >= 3 then
                m.actionTimer = m.actionTimer + 1

                --End sleep-talk
                if m.actionTimer >= SLEEP_TALK_END then
                    m.actionTimer = STARTING_SNORE
                end
    
                --Enough snores? Start sleep-talk
                if m.actionTimer == SLEEP_TALK_START then
                    play_custom_character_sound(m, SNORE3_TABLE[3])
                
                --Regular snoring
                elseif m.actionTimer < SLEEP_TALK_START then
                    play_custom_character_sound(m, SNORE3_TABLE[1])
                end
            
            --Definitely regular snoring
            else
                play_custom_character_sound(m, SNORE3_TABLE[1])
            end
        end

    --No CHAR_SOUND_SNORING3, just use regular snoring
    elseif animFrame == 2 then
        play_character_sound(m, CHAR_SOUND_SNORING2)

    elseif animFrame == 25 then
        play_character_sound(m, CHAR_SOUND_SNORING1)
    end
end
hook_event(HOOK_MARIO_UPDATE, custom_character_snore)