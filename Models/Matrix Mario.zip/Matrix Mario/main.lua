-- name: Matrix Mario
-- description: Hello Mr Anderson\n\nModel created by Kurobutt\nMod created by Dragonary

E_MODEL_MATRIX = smlua_model_util_get_id("matrix_geo")

function matrix(msg)
	if msg == "blue" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "red" then
		gPlayerSyncTable[0].modelId = E_MODEL_MATRIX
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("matrix", "[red|blue] - Take the red pill or the blue pill", matrix)