-- name: Klonoa
-- description: Play as Klonoa!\nYou can choose between 2 variants: DtP or LV\n\nModel created by Kurobutt\nMod created by Dragonary

E_MODEL_DTP = smlua_model_util_get_id("dtp_geo")
E_MODEL_LV = smlua_model_util_get_id("lv_geo")

function klonoa(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "dtp" then
		gPlayerSyncTable[0].modelId = E_MODEL_DTP
		return true
	elseif msg == "lv" then
		gPlayerSyncTable[0].modelId = E_MODEL_LV
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("klonoa", "[dtp|lv|off] - Play as Klonoa", klonoa)