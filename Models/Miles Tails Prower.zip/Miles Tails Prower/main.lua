-- name: Tails
-- description: Play as Tails\n\nMod created by Dragonary

E_MODEL_TAILS = smlua_model_util_get_id("tails_geo")

function tails(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "on" then
		gPlayerSyncTable[0].modelId = E_MODEL_TAILS
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("tails", "[on|off] - Play as Tails", tails)