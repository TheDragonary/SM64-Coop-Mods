-- name: Natsuki
-- description: Play as Natsuki from DDLC!\n\nModel created by DusterBuster\nMod created by Dragonary

E_MODEL_NATSUKI = smlua_model_util_get_id("natsuki_geo")

function natsuki(msg)
	if msg == "off" then
		gPlayerSyncTable[0].modelId = nil
		return true
	elseif msg == "on" then
		gPlayerSyncTable[0].modelId = E_MODEL_NATSUKI
		return true
	end
end

function mario_update(m)
   if gPlayerSyncTable[m.playerIndex].modelId ~= nil then
      obj_set_model_extended(m.marioObj, gPlayerSyncTable[m.playerIndex].modelId)
   end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_chat_command("natsuki", "[on|off] - Play as Natsuki", natsuki)