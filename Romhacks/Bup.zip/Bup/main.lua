-- name: Bup
-- description: Bup\n\nA short hack containing some extremely tedious & questionable activities with a giant Bup.\nOnly has one level with 6 stars.\n\nCreated by ben3759\nPorted to co-op by Dragonary
-- incompatible: romhack

gLevelValues.entryLevel = LEVEL_BOB

smlua_text_utils_course_acts_replace(COURSE_BOB,(" 1 BLJ THE BUP'S COCK"),("CLIMBING"),("IN BUP'S ASS"),("GBJ INSIDE BUP'S HEAD"),("CLIMBING AGAIN"),("PRECISE JUMP"),("FIRMLY GRASP IT"))

function restart()
    warp_restart_level()
	gMarioStates[0].health = 0x0880
	return true
end

hook_event(HOOK_ON_DEATH, restart)