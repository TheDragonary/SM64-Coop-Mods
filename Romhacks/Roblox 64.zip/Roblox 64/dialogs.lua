smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, ("I told Kaze that if he\
played Gary Come\
Home on stream, then\
I would make Roblox\
64.\
\
He ended up playing\
the song. Shoutouts\
to Kaze for this one.\
Credits are on the\
sign to the right."))

smlua_text_utils_dialog_replace(DIALOG_001,1,6,95,200, ("- Credits -\
Skelux - SM64 Editor\
Pilz - Text Editor\
Miles - Tweaks\
Bacon - More Tweaks\
Kaze - MOP\
Shoutouts to PastaPower\
for taking the time to\
make v1.2 and the\
Gary Come Home\
song in the death\
room."))

smlua_text_utils_dialog_replace(DIALOG_002,1,5,95,200, ("Long-Jump through\
the healing heart to\
lava-bounce across\
and recover health\
in the process."))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("That's it. It's over.\
Thank god it's only\
one star. Well. Was it\
worth it? You played\
through another\
meme hack. Stars\
don't save in this\
hack anyways, so\
you kinda wasted\
your time tbh."))