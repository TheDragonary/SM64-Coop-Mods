ALIGNED8 u8 pss_1__texture_0E000010[] = {
#include "levels/pss/pss_1_0xe000010_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E000050[] = {
#include "levels/pss/pss_1_0xe000050_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E001050[] = {
#include "levels/pss/pss_1_0xe001050_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E002050[] = {
#include "levels/pss/pss_1_0xe002050_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E002090[] = {
#include "levels/pss/pss_1_0xe002090_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E003090[] = {
#include "levels/pss/pss_1_0xe003090_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E0030D0[] = {
#include "levels/pss/pss_1_0xe0030d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E0040D0[] = {
#include "levels/pss/pss_1_0xe0040d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E004110[] = {
#include "levels/pss/pss_1_0xe004110_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E005110[] = {
#include "levels/pss/pss_1_0xe005110_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E005150[] = {
#include "levels/pss/pss_1_0xe005150_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E006150[] = {
#include "levels/pss/pss_1_0xe006150_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E006190[] = {
#include "levels/pss/pss_1_0xe006190_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E007190[] = {
#include "levels/pss/pss_1_0xe007190_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E0071D0[] = {
#include "levels/pss/pss_1_0xe0071d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E007210[] = {
#include "levels/pss/pss_1_0xe007210_custom.rgba16.inc.c"
};
ALIGNED8 u8 pss_1__texture_0E008210[] = {
#include "levels/pss/pss_1_0xe008210_custom.rgba16.inc.c"
};
