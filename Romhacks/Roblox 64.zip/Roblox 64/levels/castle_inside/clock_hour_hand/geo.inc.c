// 0x0E001548
const GeoLayout castle_geo_001548[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, inside_castle_seg7_dl_07059190),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
