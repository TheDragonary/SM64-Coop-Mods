#ifndef CASTLE_INSIDE_1_HEADER_H
#define CASTLE_INSIDE_1_HEADER_H
#include "types.h"
extern Vtx VB_castle_inside_1_0xe0010d0[];
extern Vtx VB_castle_inside_1_0xe0011c0[];
extern Vtx VB_castle_inside_1_0xe0012b0[];
extern Vtx VB_castle_inside_1_0xe0013a0[];
extern Vtx VB_castle_inside_1_0xe001490[];
extern Vtx VB_castle_inside_1_0xe001580[];
extern Vtx VB_castle_inside_1_0xe001670[];
extern Vtx VB_castle_inside_1_0xe001760[];
extern Vtx VB_castle_inside_1_0xe001850[];
extern Vtx VB_castle_inside_1_0xe001940[];
extern Vtx VB_castle_inside_1_0xe001a30[];
extern Vtx VB_castle_inside_1_0xe001b20[];
extern Vtx VB_castle_inside_1_0xe001c10[];
extern Vtx VB_castle_inside_1_0xe001d00[];
extern u8 castle_inside_1__texture_0E000050[];
extern u8 castle_inside_1__texture_0E000090[];
extern Light_t Light_castle_inside_1_0xe000000;
extern Ambient_t Light_castle_inside_1_0xe000008;
extern Gfx DL_castle_inside_1_0xe001df0[];
extern u8 castle_inside_1__texture_0E001090[];
extern Gfx DL_castle_inside_1_0xe002418[];
#endif