ALIGNED8 u8 castle_inside_1__texture_0E000050[] = {
#include "levels/castle_inside/castle_inside_1_0xe000050_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E000090[] = {
#include "levels/castle_inside/castle_inside_1_0xe000090_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_inside_1__texture_0E001090[] = {
#include "levels/castle_inside/castle_inside_1_0xe001090_custom.rgba16.inc.c"
};
