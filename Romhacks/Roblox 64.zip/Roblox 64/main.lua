-- name: Roblox 64
-- description: Roblox obby\n\nCreated by SwiftySky\nPorted to co-op by Dragonary
-- incompatible: romhack

gLevelValues.entryLevel = LEVEL_PSS

camera_set_use_course_specific_settings(false)

smlua_audio_utils_replace_sequence(0x02, 0x17, 75, "02_Seq_custom")
smlua_audio_utils_replace_sequence(0x0B, 0x25, 75, "0B_Seq_custom")

smlua_text_utils_secret_star_replace(18 + 1, ("2008 OBBY"))