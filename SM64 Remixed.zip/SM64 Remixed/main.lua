-- name: SM64 Remixed
-- description: Music mod that changes almost every track into remixed songs using the SM64 soundfont\n\nIncludes songs like:\nFeel Good Inc\nDon't Stop Me Now\nGangsta's Paradise\nAfrica\nAnd more!\n\nMod created by Dragonary\nBased on the Streaming Music mod created by Farris

-----------------------------------------------------------------------------
--                                Music Mod                                --
-----------------------------------------------------------------------------
local bgms = {
	--Cap [-2]
	[-2] = {audio='Never Gonna Give You Up.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Never Gonna Give You Up"},
	--Castle Grounds [16]
	[16] = {audio='Feel Good Inc.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Feel Good Inc"},
	--Castle Main Floor [6]
	[6] = {audio='Gimme Gimme Gimme.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Gimme! Gimme! Gimme!"},
	--Castle Courtyard [26]
	[26] = {audio='Feel Good Inc.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Feel Good Inc"},
	--Bob-omb Battlefield [9]	
	[9] = {audio='Jump.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Jump"},
	--Whomp's Fortress [24] 
	[24] = {audio='Ballin.ogg', loopEnd = 1000, loopStart = 18, volume = 1, name="Ballin"},
	--Jolly Roger Bay [12]
	[12] = {audio='Cosmic Cove Galaxy.ogg', loopEnd = 1000, loopStart = 0, volume = 5, name="Cosmic Cove Galaxy"},
	--Cool, Cool Mountain [5]
	[5] = {audio='Music Sounds Better With You.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Music Sounds Better With You"},
	--Big Boo's Haunt [4]
	[4] = {audio='Its Been So Long.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="It's Been So Long"},
	--Hazy Maze Cave [7]
	[7] = {audio='Somebody That I Used to Know.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Somebody That I Used to Know"},
	--Lethal Lava Land [22]
	[22] = {audio='Gangstas Paradise.ogg', loopEnd = 1000, loopStart = 0, volume = 2, name="Gangsta's Paradise"},
	--Shifting Sand Land [8]
	[8] = {audio='Paint It Black.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Paint It Black"}, 
	--Dire, Dire Docks [23]
	[23] = {audio='Cosmic Cove Galaxy.ogg', loopEnd = 1000, loopStart = 0, volume = 5, name="Cosmic Cove Galaxy"},
	--Snowman's Land [10]
	[10] = {audio='Safe and Sound.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Safe and Sound"},
	--Wet-Dry World [11]
	[11] = {audio='Feel Good Inc.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Feel Good Inc"},
	--Tall, Tall Mountain [36]
	[36] = {audio='Africa.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Africa"},
	--Tiny-Huge Island [13]
	[13] = {audio='Stayin Alive.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Stayin' Alive"},
	--Tick Tock Clock [14]
	[14] = {audio='Bad Piggies.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Bad Piggies"}, 
	--Rainbow Ride [15]
	[15] = {audio='September.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="September"},
	--Bowser in the Dark World [17]
	[17] = {audio='Rasputin.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Rasputin"}, 
	--Bowser in the Fire Sea [19]
	[19] = {audio='Smells Like Teen Spirit.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Smells Like Teen Spirit"}, 
	--Bowser in the Sky [21]
	[21] = {audio='It Has To Be This Way.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="It Has To Be This Way"}, 
	--The Princess's Secret Slide [27]
	[27] = {audio='September.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="September"},
	--The Secret Aquarium [20]
	[20] = {audio='Cosmic Cove Galaxy.ogg', loopEnd = 1000, loopStart = 0, volume = 5, name="Cosmic Cove Galaxy"},
	--Tower of the Wing Cap [29]
	[29] = {audio='Levels.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Levels"}, 
	--Vanish Cap Under the Moat [18]
	[18] = {audio='Holding out for a Hero.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Holding out for a Hero"},
	--Cavern of the Metal Cap [28]
	[28] = {audio='Everlong.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Everlong"}, 
	--Wing Mario Over the Rainbow [31]
	[31] = {audio='Levels.ogg', loopEnd = 1000, loopStart = 0, volume = 1, name="Levels"}, 
}

local pauseMenuShouldShowMusic = false
local pauseMenuMusicRGBA = {200,200,200,255}
local pauseMenuShowLevelID = false

local curMap = -1
local audioMainPaused = false
local audioMain = nil --Used for the main audio
local audioSpecial = nil --Used for things like cap music
local audioCurSeq = nil

function handleMusic()
	------------------------------------------------------
    --          Handle stopping/starting of music       --
	------------------------------------------------------
	--Handle main course music
    if (curMap ~= gNetworkPlayers[0].currLevelNum and gMarioStates[0].area.macroObjects ~= nil) then
        curMap = gNetworkPlayers[0].currLevelNum
		audioCurSeq = get_current_background_music()
        if (audioMain ~= nil) then
            audio_stream_stop(audioMain)
            audio_stream_destroy(audioMain)
            audioMain = nil
        end
        if (bgms[curMap] ~= nil and bgms[curMap].audio ~= nil) then 
            set_background_music(0,0,0)
            audioMain = audio_stream_load(bgms[curMap].audio)
            if (audioMain ~= nil) then
                audio_stream_set_looping(audioMain, true)
                audio_stream_play(audioMain, true, bgms[curMap].volume);
                print("Playing new audio " .. bgms[curMap].name)
            else
                djui_popup_create('Missing audio!: ' .. bgms[curMap].audio, 10)
                print("Attempted to load filed audio file, but couldn't find it on the system: " .. bgms[curMap].audio)
            end
        else
            print("No audio for this map, so not stopping default: " .. curMap)
        end
    end
	--Handle cap music
	if (gMarioStates[0].capTimer > 0 and bgms[-2] ~= nil) then
		--Handle pausing main streamed music, if applicable.
		if (audioMain ~= nil and audioMainPaused == false) then
			audioMainPaused = true
			audio_stream_pause(audioMain)
		end
		--Start up cap music if it's defined.
		if (audioSpecial == nil) then
            set_background_music(0,0,0)
			stop_cap_music()
			audioSpecial = audio_stream_load(bgms[-2].audio)
			if (audioSpecial ~= nil) then
				audio_stream_set_looping(audioSpecial, true)
				audio_stream_play(audioSpecial, true, bgms[-2].volume)
				print("Playing cap audio " .. bgms[-2].name)
			else
				djui_popup_create('Missing audio!: ' .. bgms[-2].audio, 3)
                print("Attempted to load filed audio file, but couldn't find it on the system: " .. bgms[-2].audio)
			end
		end	
	else
		if (audioSpecial ~= nil) then
			audio_stream_stop(audioSpecial)
			audio_stream_destroy(audioSpecial)
			audioSpecial = nil
			if (audioMain ~= nil and audioMainPaused == true) then
				audioMainPaused = false
				audio_stream_play(audioMain, false, bgms[curMap].volume)
			else
				set_background_music(0, audioCurSeq, 10) 
			
			end
		end
	end
	------------------------------------------------------
    --                Handle music looping              --
	------------------------------------------------------
    if (audioMain ~= nil) then 
		local curPosition = audio_stream_get_position(audioMain)
		if (curPosition >= bgms[curMap].loopEnd ) then
			local minus = bgms[curMap].loopStart - bgms[curMap].loopEnd
			audio_stream_set_position(audioMain, curPosition - math.abs(minus))
		end
    end
	if (audioSpecial ~= nil) then
		local curPosition = audio_stream_get_position(audioSpecial)
		if (curPosition >= bgms[-2].loopEnd) then
			local minus = bgms[-2].loopStart - bgms[-2].loopEnd
			audio_stream_set_position(audioSpecial, curPosition - math.abs(minus))
		end
	end
end

function hud_render()
    if (pauseMenuShouldShowMusic == true and is_game_paused()) then
        djui_hud_set_resolution(RESOLUTION_DJUI);
        djui_hud_set_font(FONT_NORMAL);
        local screenWidth = djui_hud_get_screen_width()
		local screenHeight = djui_hud_get_screen_height()
        local height = 64
        local y = screenHeight - height
        djui_hud_set_color(pauseMenuMusicRGBA[1], pauseMenuMusicRGBA[2], pauseMenuMusicRGBA[3], pauseMenuMusicRGBA[4]);		
		local text = "";
		if (pauseMenuShowLevelID == true) then
			text = "Level ID: " .. gNetworkPlayers[0].currLevelNum
		elseif (audioSpecial ~= nil) then
			text = "Music: " .. bgms[-2].name
		elseif (audioMain ~= nil) then
			text = "Music: " .. bgms[curMap].name
		end
		djui_hud_print_text(text, 5, y, 1);
    end
end
hook_event(HOOK_ON_HUD_RENDER, hud_render)
hook_event(HOOK_UPDATE, handleMusic)
-----------------------------------------------------------------------------
--                           Music Mod End                                 --
-----------------------------------------------------------------------------